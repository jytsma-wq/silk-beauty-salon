'use client';

// Galderma Aesthetics - French Beauty Clinic Configuration
const CLINIC_INFO = {
  name: 'Galderma Aesthetics',
  address: '123 Avenue des Champs-Élysées, 75008 Paris, France',
  phone: '+33 1 23 45 67 89',
  email: 'info@galderma-aesthetics.fr',
  instagram: 'https://instagram.com/galderma_aesthetics',
  facebook: 'https://facebook.com/galderma_aesthetics',
  tiktok: 'https://tiktok.com/@galderma_aesthetics',
  coordinates: {
    lat: 48.8698,
    lng: 2.3078,
  },
  hours: [
    { day: 'Mon – Fri', hours: '10:00 – 19:00' },
    { day: 'Saturday', hours: '10:00 – 17:00' },
    { day: 'Sunday', hours: 'Closed' },
  ],
} as const;

const PRICE_RANGE = {
  min: 150,
  max: 2500,
  currency: 'EUR',
};

interface OpeningHoursSpecification {
  '@type': 'OpeningHoursSpecification';
  dayOfWeek: string | string[];
  opens: string;
  closes: string;
}

interface GeoCoordinates {
  '@type': 'GeoCoordinates';
  latitude: number;
  longitude: number;
}

interface PostalAddress {
  '@type': 'PostalAddress';
  streetAddress: string;
  addressLocality: string;
  addressRegion: string;
  postalCode: string;
  addressCountry: string;
}

interface BeautySalonSchema {
  '@context': 'https://schema.org';
  '@type': 'BeautySalon' | 'MedicalClinic';
  name: string;
  image: string;
  description: string;
  url: string;
  telephone: string;
  email: string;
  address: PostalAddress;
  geo: GeoCoordinates;
  openingHoursSpecification: OpeningHoursSpecification[];
  priceRange: string;
  currenciesAccepted: string;
  paymentAccepted: string;
  areaServed: {
    '@type': 'City';
    name: string;
  };
  sameAs: string[];
}

interface Offer {
  '@type': 'Offer';
  itemOffered: {
    '@type': 'Service';
    name: string;
    description: string;
  };
  price?: number;
  priceCurrency?: string;
}

interface ServiceSchema {
  '@context': 'https://schema.org';
  '@type': 'Service';
  name: string;
  description: string;
  provider: {
    '@type': 'BeautySalon';
    name: string;
    url: string;
  };
  areaServed: {
    '@type': 'City';
    name: string;
  };
  offers?: Offer;
}

interface BreadcrumbItem {
  name: string;
  item: string;
}

interface BreadcrumbSchema {
  '@context': 'https://schema.org';
  '@type': 'BreadcrumbList';
  itemListElement: {
    '@type': 'ListItem';
    position: number;
    name: string;
    item: string;
  }[];
}

interface LocalBusinessSchemaProps {
  type?: 'BeautySalon' | 'MedicalClinic';
  additionalImages?: string[];
  breadcrumbItems?: BreadcrumbItem[];
  serviceData?: {
    name: string;
    description: string;
    price?: number;
  };
}

export function StructuredData({
  type = 'BeautySalon',
  additionalImages = [],
  breadcrumbItems,
  serviceData,
}: LocalBusinessSchemaProps) {
  const baseUrl = 'https://example-clinic.com';
  const mainImage = `${baseUrl}/og-image.jpg`;
  const allImages = [mainImage, ...additionalImages];

  const openingHours: OpeningHoursSpecification[] = [
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
      opens: '10:00',
      closes: '19:00',
    },
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: 'Saturday',
      opens: '10:00',
      closes: '17:00',
    },
  ];

  const address: PostalAddress = {
    '@type': 'PostalAddress',
    streetAddress: '123 Avenue des Champs-Élysées',
    addressLocality: 'Paris',
    addressRegion: 'Île-de-France',
    postalCode: '75008',
    addressCountry: 'FR',
  };

  const geo: GeoCoordinates = {
    '@type': 'GeoCoordinates',
    latitude: CLINIC_INFO.coordinates.lat,
    longitude: CLINIC_INFO.coordinates.lng,
  };

  const beautySalonSchema: BeautySalonSchema = {
    '@context': 'https://schema.org',
    '@type': type,
    name: CLINIC_INFO.name,
    image: allImages[0],
    description:
      'Galderma Aesthetics in Paris offers world-class French beauty treatments including luxury botox, dermal fillers, and advanced skincare by certified aesthetic specialists. Experience the art of French elegance.',
    url: baseUrl,
    telephone: CLINIC_INFO.phone,
    email: CLINIC_INFO.email,
    address,
    geo,
    openingHoursSpecification: openingHours,
    priceRange: '$$$',
    currenciesAccepted: 'EUR, USD',
    paymentAccepted: 'Cash, Credit Card, Debit Card',
    areaServed: {
      '@type': 'City',
      name: 'Paris',
    },
    sameAs: [
      CLINIC_INFO.facebook,
      CLINIC_INFO.instagram,
      CLINIC_INFO.tiktok,
    ],
  };

  const schemas: (BeautySalonSchema | BreadcrumbSchema | ServiceSchema)[] = [
    beautySalonSchema,
  ];

  if (breadcrumbItems && breadcrumbItems.length > 0) {
    const breadcrumbSchema: BreadcrumbSchema = {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: breadcrumbItems.map((item, index) => ({
        '@type': 'ListItem',
        position: index + 1,
        name: item.name,
        item: item.item,
      })),
    };
    schemas.push(breadcrumbSchema);
  }

  if (serviceData) {
    const serviceSchema: ServiceSchema = {
      '@context': 'https://schema.org',
      '@type': 'Service',
      name: serviceData.name,
      description: serviceData.description,
      provider: {
        '@type': 'BeautySalon',
        name: CLINIC_INFO.name,
        url: baseUrl,
      },
      areaServed: {
        '@type': 'City',
        name: 'Paris',
      },
      offers: serviceData.price
        ? {
            '@type': 'Offer',
            itemOffered: {
              '@type': 'Service',
              name: serviceData.name,
              description: serviceData.description,
            },
            price: serviceData.price,
            priceCurrency: PRICE_RANGE.currency,
          }
        : undefined,
    };
    schemas.push(serviceSchema);
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: JSON.stringify(schemas.length === 1 ? schemas[0] : schemas),
      }}
    />
  );
}

export function LocalBusinessSchema() {
  return <StructuredData type="BeautySalon" />;
}

export function MedicalClinicSchema() {
  return <StructuredData type="MedicalClinic" />;
}

export function TreatmentSchema({
  name,
  description,
  price,
  breadcrumbItems,
}: {
  name: string;
  description: string;
  price?: number;
  breadcrumbItems?: BreadcrumbItem[];
}) {
  return (
    <StructuredData
      type="MedicalClinic"
      serviceData={{ name, description, price }}
      breadcrumbItems={breadcrumbItems}
    />
  );
}

export function BreadcrumbSchema({
  items,
}: {
  items: BreadcrumbItem[];
}) {
  const schema: BreadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.item,
    })),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

export default StructuredData;
