import type { Metadata, Viewport } from 'next';
import { Cormorant_Garamond, DM_Sans, Cinzel } from 'next/font/google';
import './globals.css';

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-cormorant',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600'],
  variable: '--font-dm-sans',
  display: 'swap',
});

const cinzel = Cinzel({
  subsets: ['latin'],
  weight: ['400', '600', '700'],
  variable: '--font-cinzel',
  display: 'swap',
});

export const metadataBase = new URL('https://example-clinic.com');

export const metadata: Metadata = {
  metadataBase,
  title: {
    template: '%s | Galderma Aesthetics',
    default: 'Galderma Aesthetics | Premium French Beauty Clinic & Skincare Excellence',
  },
  description:
    'Experience the art of French beauty at Galderma Aesthetics. Luxury botox, dermal fillers, and advanced skincare treatments by certified specialists. Elevate your natural elegance with our bespoke aesthetic services.',
  keywords: [
    'aesthetics',
    'botox',
    'fillers',
    'French beauty',
    'skincare clinic',
    'dermal fillers',
    'anti-aging',
    'luxury aesthetics',
    'medical spa',
    'skin rejuvenation',
    'facial treatments',
    'aesthetic medicine',
    'beauty clinic',
    'wrinkle treatment',
    'lip enhancement',
  ],
  authors: [{ name: 'Galderma Aesthetics' }],
  creator: 'Galderma Aesthetics',
  publisher: 'Galderma Aesthetics',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://example-clinic.com',
    siteName: 'Galderma Aesthetics',
    title: 'Galderma Aesthetics | Premium French Beauty Clinic',
    description: 'Experience the art of French beauty. Luxury botox, dermal fillers, and advanced skincare treatments by certified specialists.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Galderma Aesthetics - Premium French Beauty Clinic',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Galderma Aesthetics | Premium French Beauty Clinic',
    description: 'Experience the art of French beauty. Luxury botox, dermal fillers, and advanced skincare treatments.',
    images: ['/og-image.jpg'],
    creator: '@galderma_aesthetics',
  },
  verification: {
    google: 'google-site-verification-code',
  },
  alternates: {
    canonical: '/',
    languages: {
      'en-US': '/en',
      'nl-NL': '/nl',
    },
  },
  category: 'beauty_salon',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#ffffff',
  colorScheme: 'light',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      className={`${cormorant.variable} ${dmSans.variable} ${cinzel.variable}`}
      suppressHydrationWarning
    >
      <body className="antialiased bg-[#0d0a08] text-stone-400 font-sans">
        {children}
      </body>
    </html>
  );
}
